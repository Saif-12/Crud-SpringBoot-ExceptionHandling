package com.saif.crud.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.saif.crud.Entity.Employee;

@Service
public interface EmployeeService {
	
	
	public Employee saveEmployee(Employee emp);
	
	public List<Employee> getAllEmployees();
	
	public Employee getEmpById(Long  empId);
	
	public Employee updateEmployee(Employee emp);
	
	public void deleteEmployee(Long id);
	

}
