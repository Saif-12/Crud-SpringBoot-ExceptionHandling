package com.saif.crud.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saif.crud.Entity.Employee;
import com.saif.crud.Service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/save")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee emp) {
		Employee savedEmployee = employeeService.saveEmployee(emp);
		return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
	}

	@GetMapping("/getAll")
	public ResponseEntity<?> getAllEmployee() {
		List<Employee> allEmployees = employeeService.getAllEmployees();

		return new ResponseEntity<>(allEmployees, HttpStatus.OK);
	}
	// find employee by id

	@GetMapping("/getSingle")
	// public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Long
	// empId)
	public ResponseEntity<Employee> getEmployeeById(@RequestParam("empId") Long empId) {
		Employee employee = employeeService.getEmpById(empId);
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	
	// update employee by using employee id
	@PutMapping("/updateEmp")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp) {
		Employee updatedEmployee = employeeService.updateEmployee(emp);
		return new ResponseEntity<Employee>(updatedEmployee, HttpStatus.OK);
	}
	//delete employee by using id
	@DeleteMapping("/deleteEmp/{id}")
	public String deleteEmployee(@PathVariable("id") Long id)
	{
		employeeService.deleteEmployee(id);
		return "Employee woth given id is deleted!!";
	}
}
