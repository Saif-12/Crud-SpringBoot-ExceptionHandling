package com.saif.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudUsingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudUsingSpringBootApplication.class, args);
	}

}
