package com.saif.crud.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saif.crud.Entity.Employee;
import com.saif.crud.Repositories.EmployeeRepositories;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepositories employeeRepositories;

	public Employee saveEmployee(Employee emp) {

		return employeeRepositories.save(emp);

	}

	public List<Employee> getAllEmployees() {
		List<Employee> all = employeeRepositories.findAll();
		return all;
	}

	public Employee getEmpById(Long empId) {
		return employeeRepositories.findById(empId).get();

	}

	public Employee updateEmployee(Employee emp) {
		Employee employee = employeeRepositories.save(emp);
		return employee;

	}

	@Override
	public void deleteEmployee(Long id) {
		Employee employee = employeeRepositories.findById(id).get();

		employeeRepositories.delete(employee);

	}

}
